#include <iostream>

using namespace std;

int main(){
    cout << "Hello, world!" << endl;
    double d = 8.2;
    int a = 5;
    int c = 6;
    a = c + 5;
    
    return 0;
}
